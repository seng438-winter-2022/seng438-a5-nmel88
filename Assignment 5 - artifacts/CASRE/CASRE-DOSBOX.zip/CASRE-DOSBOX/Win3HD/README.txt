To save or open files from your home directory/profile directory open/save files to/from the [-e-] drive. 
My Documents or Downloads are folders in this directory. If you save your files directory to the [-e-]
drive, they will show up in "C:\Users\$YOURUSERNAME$" where $YOURUSERNAME$ is your IT User account.
It will be faster to save your file under [docume~1] as this will show up in "My Documents" or "Documents".

If you save your files to [-a-], [-c-], [-y-] or [-z-]; you will not be able to access them.

Importantly, if you download a file while CASRE is running and you want to open it in CASRE, you need to
press "CTRL-F4" to update the file listing in CASRE.

To escape the mouse from CASRE, use "ALT-TAB" or "CTRL-F10".